//
//  ItemCollectionViewCell.swift
//  Mobile
//
//  Created by Anna  on 5/24/20.
//  Copyright © 2020 Anna. All rights reserved.
//

import UIKit

class ItemCollectionViewCell: UICollectionViewCell {

    
    @IBOutlet weak var imageView: UIImageView!

    @IBOutlet weak var authorLabel: UILabel!
    
    @IBOutlet weak var titlelabel: UILabel!
    //    override func awakeFromNib() {
//        super.awakeFromNib()
//        // Initialization code
//    }

}
