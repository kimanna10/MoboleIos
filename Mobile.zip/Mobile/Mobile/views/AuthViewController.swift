//
//  AuthViewController.swift
//  Mobile
//
//  Created by Anna  on 5/24/20.
//  Copyright © 2020 Anna. All rights reserved.
//

import UIKit
import FirebaseAuth
import Firebase

class AuthViewController: UIViewController {
    var signup:Bool = true {
        willSet{
            if newValue{
                signLabel.text = "Registration"
                nameField.isHidden = false
                signButton.setTitle("Sign Up", for: .normal)
                questionLabel.text = "Already ave an account?"
                signChange.setTitle("Sign In", for: .normal)
            }else{
                signLabel.text = "Sign In"
                nameField.isHidden = true
                signButton.setTitle("Sign In", for: .normal)
                questionLabel.text = "Don't have an account?"
                signChange.setTitle("Sign Up", for: .normal)

            }
        }
    }
    @IBOutlet weak var signLabel: UILabel!
    @IBOutlet weak var nameField: UITextField!
    @IBOutlet weak var emailField: UITextField!
    @IBOutlet weak var passField: UITextField!
    @IBOutlet weak var signButton: UIButton!
    @IBOutlet weak var signChange: UIButton!
    @IBOutlet weak var questionLabel: UILabel!
    
    
    override func viewDidLoad() {
        
        under()
        
        
        super.viewDidLoad()
        nameField.delegate = self
        emailField.delegate = self
        passField.delegate = self

        // Do any additional setup after loading the view.
    }
    

    @IBAction func signSwitch(_ sender: UIButton) {
          signup = !signup
    }
    func under (){
    let bottomLine = CALayer()
        let bottomLine2 = CALayer()
        let bottomLine3 = CALayer()


    bottomLine.frame = CGRect(origin: CGPoint(x: 0, y:nameField.frame.height - 1), size: CGSize(width: nameField.frame.width, height:  1))
    bottomLine.backgroundColor = UIColor.lightGray.cgColor
    nameField.borderStyle = UITextField.BorderStyle.none
    nameField.layer.addSublayer(bottomLine)
        
        bottomLine2.frame = CGRect(origin: CGPoint(x: 0, y:emailField.frame.height - 1), size: CGSize(width: emailField.frame.width, height:  1))
        bottomLine2.backgroundColor = UIColor.lightGray.cgColor
        emailField.borderStyle = UITextField.BorderStyle.none
        emailField.layer.addSublayer(bottomLine2)
        
        bottomLine3.frame = CGRect(origin: CGPoint(x: 0, y:passField.frame.height - 1), size: CGSize(width: passField.frame.width, height:  1))
        bottomLine3.backgroundColor = UIColor.lightGray.cgColor
        passField.borderStyle = UITextField.BorderStyle.none
        passField.layer.addSublayer(bottomLine3)
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    func showAlert(){
        let alert = UIAlertController(title: "Error", message: "Fiil all fields!", preferredStyle: .alert)
        alert.addAction(UIAlertAction(title:"OK", style: .default, handler: nil))
    present(alert, animated: true, completion: nil)
    }
   

}

extension AuthViewController:UITextFieldDelegate {
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        
    
           let name = nameField.text!
           let email = emailField.text!
           let pass = passField.text!

           if(signup){
               if(!name.isEmpty && !email.isEmpty && !pass.isEmpty){
                Auth.auth().createUser(withEmail : email, password: pass){ (result, error) in
                    if error == nil {
                        if let result = result{
                            print(result.user.uid)
                            let ref = Database.database().reference().child("users")
                            ref.child(result.user.uid).updateChildValues(["name": name, "email": email])
                            self.dismiss(animated: true, completion: nil)
                        }
                    }
                }
               }else {
                showAlert()
                }
           }else{
            if (!email.isEmpty && !pass.isEmpty){
                Auth.auth().signIn(withEmail: email, password: pass) { (result, error) in
                    if error == nil {
                        self.dismiss(animated: true, completion: nil)
                    }
                }
            }else{
                showAlert()
            }
        }
        return true
       }
   }
