//
//  MyTabBarCtrlViewController.swift
//  Mobile
//
//  Created by Anna  on 5/24/20.
//  Copyright © 2020 Anna. All rights reserved.
//

import UIKit
import SwiftIcons
import Firebase

class MyTabBarCtrlViewController: UITabBarController,  UITabBarControllerDelegate {

    required init(coder aDecoder: NSCoder) {
         super.init(coder: aDecoder)!
     }

     override func viewDidLoad() {
         super.viewDidLoad()
         self.delegate = self
         setupMiddleButton()
        
        
//         setupFavoriteButton()
//         setupProfileButton()
//         setupSearchButton()
//         setupShopButton()
         
    }
     
     // TabBarButton – Setup Middle Button
     func setupMiddleButton() {

         let middleBtn = UIButton(frame: CGRect(x: (self.view.bounds.width / 2)-32, y: -32, width: 64, height: 64))
        
         //STYLE THE BUTTON YOUR OWN WAY
        middleBtn.setIcon(icon: .fontAwesomeSolid(.home), iconSize: 20.0, color: UIColor.white, backgroundColor: UIColor.systemGreen, forState: .normal)
         middleBtn.backgroundColor = UIColor.systemGreen
        middleBtn.layer.borderWidth = 0.5
         middleBtn.layer.borderColor = UIColor.lightGray.cgColor
         middleBtn.layer.cornerRadius = middleBtn.frame.size.width / 2
         
         //add to the tabbar and add click event
         self.tabBar.addSubview(middleBtn)
         middleBtn.addTarget(self, action: #selector(self.menuButtonAction), for: .touchUpInside)

         self.view.layoutIfNeeded()
        
     }
    

//     func setupFavoriteButton() {
//
//         let favoriteBtn = UIButton(frame: CGRect(x: (self.view.bounds.width / 8)-25, y: 5, width: 25, height: 25))
//
//         //STYLE THE BUTTON YOUR OWN WAY
//        favoriteBtn.setIcon(icon: .fontAwesomeSolid(.heart), iconSize: 20.0, color: UIColor.white, backgroundColor: UIColor.clear, forState: .normal)
//        favoriteBtn.setTitle("ft", for: .normal)
//         favoriteBtn.layer.cornerRadius = favoriteBtn.frame.size.width / 2
//
//         //add to the tabbar and add click event
//         self.tabBar.addSubview(favoriteBtn)
//         favoriteBtn.addTarget(self, action: #selector(self.menuButtonAction), for: .touchUpInside)
//
//         self.view.layoutIfNeeded()
//     }
//
//     func setupProfileButton() {
//
//         let profileBtn = UIButton(frame: CGRect(x: (self.view.bounds.width / 2)+137, y: 5, width: 25, height: 25))
//
//         //STYLE THE BUTTON YOUR OWN WAY
//        profileBtn.setIcon(icon: .fontAwesomeSolid(.user), iconSize: 20.0, color: UIColor.white, backgroundColor: UIColor.clear, forState: .normal)
//
//         profileBtn.layer.cornerRadius = profileBtn.frame.size.width / 2
//
//         //add to the tabbar and add click event
//         self.tabBar.addSubview(profileBtn)
//         profileBtn.addTarget(self, action: #selector(self.menuButtonAction), for: .touchUpInside)
//
//         self.view.layoutIfNeeded()
//     }
//
//     func setupSearchButton() {
//
//         let searchBtn = UIButton(frame: CGRect(x: (self.view.bounds.width / 7)+45, y: 5, width: 25, height: 25))
//
//         //STYLE THE BUTTON YOUR OWN WAY
//        searchBtn.setIcon(icon: .fontAwesomeSolid(.search), iconSize: 20.0, color: UIColor.white, backgroundColor: UIColor.clear, forState: .normal)
//
//         searchBtn.layer.cornerRadius = searchBtn.frame.size.width / 2
//
//         //add to the tabbar and add click event
//         self.tabBar.addSubview(searchBtn)
//         searchBtn.addTarget(self, action: #selector(self.menuButtonAction), for: .touchUpInside)
//
//         self.view.layoutIfNeeded()
//     }
//
//     func setupShopButton() {
//
//         let shopBtn = UIButton(frame: CGRect(x: (self.view.bounds.width / 2)+60, y: 5, width: 25, height: 25))
//
//         //STYLE THE BUTTON YOUR OWN WAY
//         shopBtn.setIcon(icon: .fontAwesomeSolid(.shoppingCart), iconSize: 20.0, color: UIColor.white, backgroundColor: UIColor.clear, forState: .normal)
//
//         shopBtn.layer.cornerRadius = shopBtn.frame.size.width / 2
//
//         //add to the tabbar and add click event
//         self.tabBar.addSubview(shopBtn)
//         shopBtn.addTarget(self, action: #selector(self.menuButtonAction), for: .touchUpInside)
//
//         self.view.layoutIfNeeded()
//     }
     // Menu Button Touch Action
     @objc func menuButtonAction(sender: UIButton) {
         self.selectedIndex = 2   //to select the middle tab. use "1" if you have only 3 tabs.
     }
     
//     @objc func favoriteButtonAction(sender: UIButton) {
//         self.selectedIndex = 1   //to select the middle tab. use "1" if you have only 3 tabs.
//     }
//
//     @objc func profileButtonAction(sender: UIButton) {
//         self.selectedIndex = 3   //to select the middle tab. use "1" if you have only 3 tabs.
//     }
//
//     @objc func searchButtonAction(sender: UIButton) {
//         self.selectedIndex = 4   //to select the middle tab. use "1" if you have only 3 tabs.
//     }
//
//     @objc func shopButtonAction(sender: UIButton) {
//         self.selectedIndex = 5   //to select the middle tab. use "1" if you have only 3 tabs.
//     }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
