//
//  FourthViewController.swift
//  Mobile
//
//  Created by Anna  on 5/25/20.
//  Copyright © 2020 Anna. All rights reserved.
//

import UIKit
import Firebase

class FourthViewController: UIViewController {

    @IBOutlet weak var collectionView: UICollectionView!
    
    let item: UIImage = #imageLiteral(resourceName: "blank")
    var collectionViewFlowLayout: UICollectionViewFlowLayout!
    @IBOutlet weak var collectionView1: UICollectionView!
    
    let cellIdentifire = "ShopCollectionViewCell"
    
    override func viewDidLoad() {
        setUpCollectionView()
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    override func viewWillLayoutSubviews() {
                super.viewWillLayoutSubviews()
                setupCollectionViewItemSize()
            }
            private func setUpCollectionView(){
                collectionView.delegate = self
                collectionView.dataSource = self
                let nib = UINib(nibName: "ShopCollectionViewCell", bundle: nil)
                collectionView.register(nib, forCellWithReuseIdentifier: cellIdentifire)
                collectionView1.delegate = self
                collectionView1.dataSource = self
                collectionView1.register(nib, forCellWithReuseIdentifier: cellIdentifire)
            }
            private func setupCollectionViewItemSize(){
                if collectionViewFlowLayout == nil{
                    /*let numberOfItemRow: CGFloat = 3
                    let lineSpacing: CGFloat = 5
                    let interItemSpacing: CGFloat = 5*/
                    
                    let widthSize = UIScreen.main.bounds
                    let heightSize = UIScreen.main.bounds
                    let width = widthSize.width / 2
                    
                    /*let width = (collectionView.frame.width - (numberOfItemRow - 1) * interItemSpacing) / numberOfItemRow*/
                    let height = heightSize.height / 4
                    collectionViewFlowLayout = UICollectionViewFlowLayout()
                    
                    collectionViewFlowLayout.itemSize = CGSize(width: width, height: height)
                    collectionViewFlowLayout.sectionInset = UIEdgeInsets(top: 5, left: 0, bottom: 10, right: 0)
                    collectionViewFlowLayout.scrollDirection = .horizontal
                    collectionViewFlowLayout.minimumLineSpacing = 0
                    collectionViewFlowLayout.minimumInteritemSpacing = 0
                    
                    collectionView.setCollectionViewLayout(collectionViewFlowLayout, animated: true)
                    collectionView1.setCollectionViewLayout(collectionViewFlowLayout, animated: true)

                    
                }
            }
            
            
        }

        extension FourthViewController: UICollectionViewDelegate, UICollectionViewDataSource {
            func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
    //            return items.count
                return 10
            }
            func collectionView1(_ collectionView1: UICollectionView, numberOfItemsInSection section: Int) -> Int {
            //            return items.count
                        return 10
                    }
            func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
                let cell = collectionView.dequeueReusableCell(withReuseIdentifier: cellIdentifire, for: indexPath) as! ShopCollectionViewCell
              
                cell.imageView.image = item
                
                return cell
            }
            private func collectionView1(_ collectionView1: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
                let cell = collectionView1.dequeueReusableCell(withReuseIdentifier: cellIdentifire, for: indexPath) as! ShopCollectionViewCell
                cell.imageView.image = item
                return cell
            }


    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
