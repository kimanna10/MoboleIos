//
//  FifthViewController.swift
//  Mobile
//
//  Created by Anna  on 5/25/20.
//  Copyright © 2020 Anna. All rights reserved.
//

import UIKit
import Firebase

class FifthViewController: UIViewController,UITableViewDelegate,
UITableViewDataSource {

    let names = ["Updates", "Books", "Notifications", "Purchases"]
    

    @IBOutlet weak var tableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.tableView.delegate = self
        self.tableView.dataSource = self
        // Do any additional setup after loading the view.
    }
 func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
     return names.count
 }
 
 func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell{
     
     let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as UITableViewCell
     if indexPath.row == 0 ||  indexPath.row == 1 ||  indexPath.row == 3{
        cell.accessoryType = .disclosureIndicator
     } else {
        cell.accessoryType = .none
     }
    if indexPath.row == 2 {
    let switchView = UISwitch(frame: .zero)
    switchView.setOn(false, animated: true)
    cell.accessoryView = switchView
    }
     cell.textLabel?.text = names[indexPath.row]
     return cell
 }
 

    @IBAction func logOut(_ sender: Any) {
        do{
            try Auth.auth().signOut()
            self.performSegue(withIdentifier: "show", sender: self)
        } catch{
            print(error)
        }
        
    }
    
   
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

