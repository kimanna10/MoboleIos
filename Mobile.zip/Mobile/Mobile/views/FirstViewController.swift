//
//  FirstViewController.swift
//  Mobile
//
//  Created by Anna  on 5/24/20.
//  Copyright © 2020 Anna. All rights reserved.
//

import UIKit
import Firebase

class FirstViewController: UIViewController {

    @IBOutlet weak var collectionView: UICollectionView!
    @IBOutlet weak var titleLabel: UILabel!
    
    let items: [UIImage] = [#imageLiteral(resourceName: "blank"),#imageLiteral(resourceName: "blank"),#imageLiteral(resourceName: "yellow")]
    let item: UIImage = #imageLiteral(resourceName: "blank")
    
    var collectionViewFlowLayout: UICollectionViewFlowLayout!
     let cellIdentifire = "ItemCollectionViewCell"
    
    override func viewDidLoad() {
        titleSet()
        setUpCollectionView()
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    func titleSet(){
        titleLabel.font = UIFont(name: "Times New Roman", size: 40)
    }
    
     override func viewWillLayoutSubviews() {
            super.viewWillLayoutSubviews()
            setupCollectionViewItemSize()
        }
        private func setUpCollectionView(){
            collectionView.delegate = self
            collectionView.dataSource = self
            let nib = UINib(nibName: "ItemCollectionViewCell", bundle: nil)
            collectionView.register(nib, forCellWithReuseIdentifier: cellIdentifire)
        }
        private func setupCollectionViewItemSize(){
            if collectionViewFlowLayout == nil{
                /*let numberOfItemRow: CGFloat = 3
                let lineSpacing: CGFloat = 5
                let interItemSpacing: CGFloat = 5*/
                
                let widthSize = UIScreen.main.bounds
                let heightSize = UIScreen.main.bounds
                let width = widthSize.width / 2
                
                /*let width = (collectionView.frame.width - (numberOfItemRow - 1) * interItemSpacing) / numberOfItemRow*/
                let height = heightSize.height / 4
                collectionViewFlowLayout = UICollectionViewFlowLayout()
                
                collectionViewFlowLayout.itemSize = CGSize(width: width, height: height)
                collectionViewFlowLayout.sectionInset = UIEdgeInsets(top: 10, left: 0, bottom: 10, right: 0)
                collectionViewFlowLayout.scrollDirection = .vertical
                collectionViewFlowLayout.minimumLineSpacing = 0
                collectionViewFlowLayout.minimumInteritemSpacing = 0
                
                collectionView.setCollectionViewLayout(collectionViewFlowLayout, animated: true)
            }
        }
        
        
    }

    extension FirstViewController: UICollectionViewDelegate, UICollectionViewDataSource {
        func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
//            return items.count
            return 15
        }
        func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: cellIdentifire, for: indexPath) as! ItemCollectionViewCell
          
            cell.imageView.image = item
            
            return cell
        }



}
