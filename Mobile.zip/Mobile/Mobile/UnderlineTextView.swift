//
//  UnderlineTextView.swift
//  Mobile
//
//  Created by Anna  on 5/24/20.
//  Copyright © 2020 Anna. All rights reserved.
//

import UIKit

class UnderlineTextView: UITextView {

    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */

}
